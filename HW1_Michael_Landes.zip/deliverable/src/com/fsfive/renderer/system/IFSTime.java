package com.fsfive.renderer.system;

/**
 * Created by Michael on 6/3/2014.
 */
public interface IFSTime {
    public long ticksPerSecond();
    public long getSystemTicks();
}
