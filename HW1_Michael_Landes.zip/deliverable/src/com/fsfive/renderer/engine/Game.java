package com.fsfive.renderer.engine;

/**
 * Created by Michael on 6/3/2014.
 */
public abstract class Game implements Runnable {}
